from flask import Flask, render_template, request
import os
import json
from dotenv import load_dotenv
import google.genai as genai

# 1. Load Environment Variables
load_dotenv()

# 2. Configure Gemini
api_key = os.getenv("GEMINI_API_KEY")
if not api_key:
    print("!!! ERROR: GEMINI_API_KEY not found in .env file")
else:
    print(f">>> API Key loaded successfully: {api_key[:5]}***")
    
# Initialize the client
client = genai.Client(api_key=api_key)

app = Flask(__name__)

# -------------------------------
# AI Quiz Generator
# -------------------------------
def generate_quiz(topic, difficulty, num_questions):
    try:
        print(f">>> Generating quiz: Topic='{topic}', Difficulty='{difficulty}', Questions={num_questions}")
        
        # Enhanced prompt for better question generation with uniqueness emphasis
        prompt = f"""Create a {difficulty} level quiz on the topic "{topic}".
Generate exactly {num_questions} UNIQUE and DIVERSE multiple choice questions.

CRITICAL REQUIREMENTS:
- Generate exactly {num_questions} questions - no more, no less
- Each question MUST be completely different and unique
- Cover different aspects/subtopics of {topic}
- Each question must have exactly 4 options (A, B, C, D)
- Only one correct answer per question
- Questions should be relevant and educational
- NO duplicate or similar questions allowed
- Vary the question types (definitions, applications, comparisons, examples)

Difficulty Level: {difficulty}
{"- Focus on basic concepts, definitions, and simple applications" if difficulty == "Easy" else "- Include intermediate concepts, practical applications, and some analysis" if difficulty == "Medium" else "- Cover advanced concepts, complex scenarios, and critical thinking"}

Return ONLY valid JSON array with exactly {num_questions} unique questions:

[
  {{
    "question": "First unique question about {topic}",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "answer": "Correct option text"
  }},
  {{
    "question": "Second completely different question about {topic}",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "answer": "Correct option text"
  }}
]

IMPORTANT: Ensure all {num_questions} questions are completely unique and cover different aspects of {topic}."""

        print(">>> Sending request to Gemini API...")
        
        # Use the new Google GenAI client with increased token limit
        response = client.models.generate_content(
            model='gemini-2.5-flash',
            contents=prompt,
            config={
                'response_mime_type': 'application/json',
                'temperature': 0.8,  # Slightly higher for more variety
                'max_output_tokens': 4096,  # Doubled token limit
                'top_p': 0.9,  # Add top_p for better diversity
            }
        )
        
        print(f">>> API Response received: {len(response.text) if response.text else 0} characters")
        
        if response.text:
            quiz_data = json.loads(response.text)
            print(f">>> Successfully parsed {len(quiz_data)} questions")
            
            # Enhanced validation with uniqueness check
            if isinstance(quiz_data, list) and len(quiz_data) > 0:
                # Check for duplicate questions
                questions_text = [q.get('question', '').lower().strip() for q in quiz_data]
                unique_questions = set(questions_text)
                
                if len(unique_questions) < len(questions_text):
                    print(f"!!! Warning: Found {len(questions_text) - len(unique_questions)} duplicate questions")
                    # Remove duplicates while preserving order
                    seen = set()
                    unique_quiz_data = []
                    for q in quiz_data:
                        question_text = q.get('question', '').lower().strip()
                        if question_text not in seen:
                            seen.add(question_text)
                            unique_quiz_data.append(q)
                    quiz_data = unique_quiz_data
                    print(f">>> After removing duplicates: {len(quiz_data)} unique questions")
                
                # Validate structure
                for i, q in enumerate(quiz_data):
                    if not all(key in q for key in ['question', 'options', 'answer']):
                        print(f"!!! Question {i+1} missing required fields")
                        raise ValueError("Invalid quiz structure")
                    if len(q['options']) != 4:
                        print(f"!!! Question {i+1} doesn't have exactly 4 options")
                        raise ValueError("Each question must have exactly 4 options")
                
                # If we don't have enough questions after deduplication, try to generate more
                if len(quiz_data) < num_questions:
                    print(f"!!! Only got {len(quiz_data)} unique questions, need {num_questions}")
                    print(">>> Attempting to generate additional questions...")
                    
                    # Generate additional questions to fill the gap
                    additional_needed = num_questions - len(quiz_data)
                    additional_quiz = generate_additional_questions(topic, difficulty, additional_needed, quiz_data)
                    quiz_data.extend(additional_quiz)
                
                print(">>> Quiz validation successful!")
                return quiz_data[:num_questions]  # Ensure we don't exceed requested number
        
        print("!!! No valid response text received")
        return generate_fallback_quiz(topic, num_questions)
            
    except json.JSONDecodeError as e:
        print(f"!!! JSON parsing error: {e}")
        print(f"!!! Raw response: {response.text if 'response' in locals() else 'No response'}")
        return generate_fallback_quiz(topic, num_questions)
    except Exception as e:
        print(f"!!! API ERROR: {type(e).__name__}: {e}")
        return generate_fallback_quiz(topic, num_questions)

def generate_additional_questions(topic, difficulty, num_needed, existing_questions):
    """Generate additional unique questions when the initial request doesn't provide enough"""
    try:
        print(f">>> Generating {num_needed} additional questions for {topic}")
        
        # Create a list of existing question texts to avoid duplicates
        existing_texts = [q.get('question', '').lower().strip() for q in existing_questions]
        
        prompt = f"""Create {num_needed} additional UNIQUE quiz questions on "{topic}" at {difficulty} level.

CRITICAL: These questions must be COMPLETELY DIFFERENT from any questions about:
{chr(10).join([f"- {q.get('question', '')}" for q in existing_questions[-3:]])}

Requirements:
- Generate exactly {num_needed} questions
- Each question must be unique and cover different aspects of {topic}
- 4 multiple choice options each
- One correct answer per question
- {difficulty} difficulty level
- NO similarity to existing questions

Return ONLY valid JSON array:
[
  {{
    "question": "Unique question about different aspect of {topic}",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "answer": "Correct option"
  }}
]"""

        response = client.models.generate_content(
            model='gemini-2.5-flash',
            contents=prompt,
            config={
                'response_mime_type': 'application/json',
                'temperature': 0.9,  # Higher temperature for more variety
                'max_output_tokens': 2048,
            }
        )
        
        if response.text:
            additional_data = json.loads(response.text)
            if isinstance(additional_data, list):
                # Filter out any duplicates
                unique_additional = []
                for q in additional_data:
                    question_text = q.get('question', '').lower().strip()
                    if question_text not in existing_texts:
                        unique_additional.append(q)
                        existing_texts.append(question_text)
                
                print(f">>> Generated {len(unique_additional)} additional unique questions")
                return unique_additional[:num_needed]
        
        print("!!! Failed to generate additional questions")
        return []
        
    except Exception as e:
        print(f"!!! Error generating additional questions: {e}")
        return []

def generate_fallback_quiz(topic, num_questions):
    """Generate a fallback quiz when API fails"""
    print(f">>> Generating fallback quiz for '{topic}' with {num_questions} questions")
    
    # Create more diverse fallback questions based on topic
    fallback_questions = []
    
    # Expanded question templates for better variety
    templates = [
        {
            "question": f"What is a fundamental concept in {topic}?",
            "options": [
                f"Basic principle of {topic}",
                f"Advanced theory in {topic}",
                f"Unrelated concept",
                f"Complex algorithm"
            ],
            "answer": f"Basic principle of {topic}"
        },
        {
            "question": f"Which of the following is most important when studying {topic}?",
            "options": [
                f"Understanding core concepts",
                f"Memorizing definitions",
                f"Ignoring fundamentals",
                f"Skipping practice"
            ],
            "answer": "Understanding core concepts"
        },
        {
            "question": f"In {topic}, what should beginners focus on first?",
            "options": [
                f"Foundation and basics",
                f"Advanced techniques only",
                f"Complex theories",
                f"Expert-level concepts"
            ],
            "answer": "Foundation and basics"
        },
        {
            "question": f"What is a common application of {topic}?",
            "options": [
                f"Practical use in real-world scenarios",
                f"Theoretical research only",
                f"Academic discussions",
                f"Historical references"
            ],
            "answer": f"Practical use in real-world scenarios"
        },
        {
            "question": f"Which skill is essential for mastering {topic}?",
            "options": [
                f"Critical thinking and analysis",
                f"Memorization only",
                f"Guessing techniques",
                f"Avoiding practice"
            ],
            "answer": f"Critical thinking and analysis"
        },
        {
            "question": f"What distinguishes {topic} from other subjects?",
            "options": [
                f"Its unique characteristics and methods",
                f"It's exactly the same as others",
                f"It has no special features",
                f"It's completely unrelated to anything"
            ],
            "answer": f"Its unique characteristics and methods"
        },
        {
            "question": f"How can one improve their understanding of {topic}?",
            "options": [
                f"Regular practice and study",
                f"Avoiding all learning materials",
                f"Only reading once",
                f"Ignoring expert advice"
            ],
            "answer": f"Regular practice and study"
        },
        {
            "question": f"What is a key benefit of learning {topic}?",
            "options": [
                f"Enhanced knowledge and skills",
                f"No benefits at all",
                f"Confusion and complexity",
                f"Wasted time and effort"
            ],
            "answer": f"Enhanced knowledge and skills"
        },
        {
            "question": f"Which approach works best for {topic}?",
            "options": [
                f"Systematic and structured learning",
                f"Random and chaotic study",
                f"Avoiding all structure",
                f"Learning without any plan"
            ],
            "answer": f"Systematic and structured learning"
        },
        {
            "question": f"What makes {topic} relevant in today's world?",
            "options": [
                f"Its practical applications and importance",
                f"It has no relevance",
                f"Only historical significance",
                f"Purely academic interest"
            ],
            "answer": f"Its practical applications and importance"
        }
    ]
    
    # Generate questions by cycling through templates and adding variations
    for i in range(num_questions):
        template_index = i % len(templates)
        base_template = templates[template_index].copy()
        
        # Add variation to make each question unique
        if i >= len(templates):
            variation_num = (i // len(templates)) + 1
            base_template["question"] = f"Question {i+1}: {base_template['question']}"
            
            # Add some variety to options
            if variation_num == 2:
                base_template["options"] = [
                    f"Advanced aspect of {topic}",
                    f"Basic element of {topic}",
                    f"Unrelated topic",
                    f"Different subject entirely"
                ]
                base_template["answer"] = f"Advanced aspect of {topic}"
            elif variation_num == 3:
                base_template["options"] = [
                    f"Important feature of {topic}",
                    f"Irrelevant information",
                    f"Outdated concept",
                    f"Unrelated material"
                ]
                base_template["answer"] = f"Important feature of {topic}"
        
        fallback_questions.append(base_template)
    
    print(f">>> Created {len(fallback_questions)} fallback questions")
    return fallback_questions

# -------------------------------
# Routes
# -------------------------------

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/quiz", methods=["POST"])
def quiz():
    topic = request.form.get("topic", "General Knowledge").strip()
    difficulty = request.form.get("difficulty", "Easy")
    
    try:
        num_questions = int(request.form.get("num_questions", "5"))
        num_questions = max(1, min(num_questions, 10))  # Ensure between 1-10
    except (ValueError, TypeError):
        num_questions = 5

    # Validate inputs
    if not topic:
        topic = "General Knowledge"
    
    if difficulty not in ["Easy", "Medium", "Hard"]:
        difficulty = "Easy"

    print(f">>> Quiz request: Topic='{topic}', Difficulty='{difficulty}', Questions={num_questions}")

    # Generate quiz using the AI
    quiz_data = generate_quiz(topic, difficulty, num_questions)
    
    print(f">>> Rendering quiz with {len(quiz_data)} questions")
    
    return render_template("quiz.html", 
                         quiz=quiz_data, 
                         total=len(quiz_data),
                         topic=topic,
                         difficulty=difficulty)

@app.route("/result", methods=["POST"])
def result():
    score = 0
    try:
        total = int(request.form.get("total", 0))
    except (ValueError, TypeError):
        total = 0

    print(f">>> Processing results for {total} questions")

    # Calculate score
    for i in range(total):
        user_answer = request.form.get(f"question_{i}")  # Updated to match new naming
        correct_answer = request.form.get(f"a{i}")
        
        print(f">>> Question {i+1}: User='{user_answer}', Correct='{correct_answer}'")
        
        if user_answer and correct_answer and user_answer.strip() == correct_answer.strip():
            score += 1

    # Calculate percentage
    percentage = (score / total * 100) if total > 0 else 0
    
    print(f">>> Final score: {score}/{total} ({percentage:.1f}%)")

    return render_template("result.html", 
                         score=score, 
                         total=total, 
                         percentage=round(percentage, 1))

@app.route("/health")
def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "AI Quiz Generator"}

@app.errorhandler(404)
def not_found(error):
    return render_template("index.html"), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template("index.html"), 500

# -------------------------------
# Start Server
# -------------------------------
if __name__ == "__main__":
    print(">>> Starting Flask server on http://localhost:8080")
    app.run(debug=True, host='0.0.0.0', port=8080)
# 🧠 AI Quiz Generator

A modern, interactive quiz application powered by Google Gemini AI that generates unique questions on any topic.

## ✨ Features

- 🤖 **AI-Powered Questions**: Generate real quiz questions using Google Gemini API
- 🎨 **Futuristic Design**: Advanced UI with particle animations and glassmorphism effects
- 📱 **Responsive**: Works perfectly on desktop, tablet, and mobile devices
- 🎯 **Interactive**: Working radio buttons with visual feedback and progress tracking
- 🔄 **Unique Questions**: Advanced duplicate detection ensures all questions are unique
- 📊 **Real-time Progress**: Visual progress bar and debug information
- 🎓 **Multiple Difficulties**: Easy, Medium, and Hard difficulty levels
- 📈 **Score Tracking**: Detailed results with percentage scores

## 🚀 Quick Start

### Prerequisites
- Python 3.11+
- Google Gemini API key

### Installation

1. **Clone or download** this project
2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```
3. **Set up environment**:
   - Create a `.env` file in the project root
   - Add your Google Gemini API key:
     ```
     GEMINI_API_KEY=your_api_key_here
     ```

### Running the Application

```bash
python app.py
```

Then open your browser and go to: `http://localhost:8080`

## 🎮 How to Use

1. **Enter a topic** (e.g., "JavaScript", "History", "Biology")
2. **Select difficulty** (Easy, Medium, Hard)
3. **Choose number of questions** (1-10)
4. **Click "INITIALIZE GENERATION"**
5. **Answer the questions** - click on radio buttons to select answers
6. **Submit for results** and see your score!

## 🛠 VS Code Development

This project includes VS Code configuration for easy development:

- **F5**: Start debugging the Flask application
- **Ctrl+Shift+P** → "Tasks: Run Task" → "Start Flask Server"

## 📁 Project Structure

```
ai-quiz-generator/
├── app.py              # Main Flask application
├── requirements.txt    # Python dependencies
├── .env               # Environment variables (API key)
├── .vscode/           # VS Code configuration
│   ├── launch.json    # Debug configuration
│   ├── settings.json  # Editor settings
│   └── tasks.json     # Build tasks
└── templates/         # HTML templates
    ├── index.html     # Home page
    ├── quiz.html      # Quiz interface
    └── result.html    # Results page
```

## 🔧 Configuration

### Environment Variables
- `GEMINI_API_KEY`: Your Google Gemini API key (required)

### API Settings
- Model: `gemini-2.5-flash`
- Max tokens: 4096
- Temperature: 0.8 (for variety)

## 🎨 Design Features

- **Particle Animation**: Dynamic neural network background
- **Glassmorphism**: Transparent cards with blur effects
- **Neon Colors**: Cyan and purple futuristic theme
- **Custom Fonts**: Orbitron and Rajdhani
- **Smooth Animations**: Progress bars and hover effects
- **Debug Panel**: Real-time selection tracking

## 🔍 Troubleshooting

### API Quota Exceeded
If you see quota errors, the app will automatically use a fallback system with pre-generated questions.

### Radio Buttons Not Working
The radio buttons have been thoroughly tested and fixed. If you encounter issues:
1. Clear browser cache
2. Restart the Flask server
3. Check browser console for errors

## 📝 License

This project is open source and available under the MIT License.

## 🤝 Contributing

Feel free to submit issues, feature requests, or pull requests to improve the application.

---

**Enjoy creating quizzes with AI!** 🎉